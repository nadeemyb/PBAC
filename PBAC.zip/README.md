Before starting this app, run

### `npm install`

Update the smart contract address and abi in Healthcare.js file.

To run the project, go to terminal and type

### `npm start`
